var express =require('express'),
        app =express(),
        bodyParser 	= require('body-parser'),
        mongoose 	= require('mongoose');
        var path = require('path');
var index = require('./routes/index');
var tasks = require('./routes/task');


 mongoose.connect("mongodb://localhost/test");


//View Engine
app.set('views', path.join(__dirname, 'views')); 
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

// Set Static Folder
app.use(express.static(path.join(__dirname, 'client')));

 // Body Parser MW
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

 
//model



//routes

app.use('/', index);
app.use('/api', tasks);

app.listen("3000", function(){
	console.log("running on server 3000");
});