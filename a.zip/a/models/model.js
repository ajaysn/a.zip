var mongoose=require('mongoose');

var optionsSchema=new mongoose.Schema(
    {
        label :String,
        value: String
    }
); 

var options= mongoose.model("option",optionsSchema);



var taskSchema = new mongoose.Schema({
	tasks: [optionsSchema]
});

var task = mongoose.model("task", taskSchema);

module.exports =task;